<?php

/**

 * The base configuration for WordPress

 *

 * The wp-config.php creation script uses this file during the

 * installation. You don't have to use the web site, you can

 * copy this file to "wp-config.php" and fill in the values.

 *

 * This file contains the following configurations:

 *

 * * MySQL settings

 * * Secret keys

 * * Database table prefix

 * * ABSPATH

 *

 * @link https://codex.wordpress.org/Editing_wp-config.php

 *

 * @package WordPress

 */


// ** MySQL settings - You can get this info from your web host ** //

/** The name of the database for WordPress */

define( 'DB_NAME', 'cfta_db' );


/** MySQL database username */

define( 'DB_USER', 'aw_cfta' );


/** MySQL database password */

define( 'DB_PASSWORD', "TalkBusinessTelephone@33" );


/** MySQL hostname */

define( 'DB_HOST', 'mysql.cfta.dev.dijatek.com' );


/** Database Charset to use in creating database tables. */

define( 'DB_CHARSET', 'utf8mb4' );


/** The Database Collate type. Don't change this if in doubt. */

define( 'DB_COLLATE', '' );


/**#@+

 * Authentication Unique Keys and Salts.

 *

 * Change these to different unique phrases!

 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}

 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.

 *

 * @since 2.6.0

 */

define( 'AUTH_KEY',         'dwqcpt8{EP0IJAMTjs7Yuhah@r.P/>%m|zfDb&GVrU!`[}*+$1FKl+LAP{J`F%MW' );

define( 'SECURE_AUTH_KEY',  '9O[XrBaqnS}oRpluPAjXri<!ISM>A2&cMjMBqDi[Ogaakh-H4&TFtae_>HAqU!L;' );

define( 'LOGGED_IN_KEY',    'wZ0QKy9F&%tv,I{kp-}GKv-7t(]=J?RE&sD/S>*Qc%hRFA=n+Zy7er;t3@Q`~MK6' );

define( 'NONCE_KEY',        '+#01;tJZ~j}D:P:U?o:1r*sab`L}}&L.zGTlr}cE qM<KJ7d /6`{QHUtnWdGqZ_' );

define( 'AUTH_SALT',        '!&26lOK}#R{4NTAEB+Z}5IU%>B6;F8}cuy9#Q+Y0I;<a)LT|j{#7R[9Zd<UpwRl>' );

define( 'SECURE_AUTH_SALT', '5z;i<O6>+yc<q[j/@];aWUpM023B}_BzkUVOV:^P.9/(@t<)98G59zOjt4gL3#5j' );

define( 'LOGGED_IN_SALT',   'mwkcL26CH`1zz}iym5R`5AIrDE%m|dEfZT4,?:,z/V/S$3Q0ztFZ%rEmi<w6Cly!' );

define( 'NONCE_SALT',       '&DYd|g|dKPu`3A`<12NCvW%UH@>Z3Ef~mN;j#Q4}aM$ucZHj61YzKeq5qpk),`>1' );


/**#@-*/


/**

 * WordPress Database Table prefix.

 *

 * You can have multiple installations in one database if you give each

 * a unique prefix. Only numbers, letters, and underscores please!

 */

$table_prefix = 'wp_';


/**

 * For developers: WordPress debugging mode.

 *

 * Change this to true to enable the display of notices during development.

 * It is strongly recommended that plugin and theme developers use WP_DEBUG

 * in their development environments.

 *

 * For information on other constants that can be used for debugging,

 * visit the Codex.

 *

 * @link https://codex.wordpress.org/Debugging_in_WordPress

 */

define( 'WP_DEBUG', false );


/* That's all, stop editing! Happy publishing. */


/** Absolute path to the WordPress directory. */

if ( ! defined( 'ABSPATH' ) ) {

	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

}


/** Sets up WordPress vars and included files. */

require_once( ABSPATH . 'wp-settings.php' );

